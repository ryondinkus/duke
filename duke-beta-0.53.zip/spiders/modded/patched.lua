return {
    use = include("spiders/red"),
    heart = DukeHelpers.Hearts.PATCHED,
    count = 2
}
