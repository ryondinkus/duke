return {
    use = include("flies/red"),
    heart = DukeHelpers.Hearts.SCARED,
    count = 2
}
