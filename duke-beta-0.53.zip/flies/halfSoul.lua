return {
    use = include("flies/soul"),
    heart = DukeHelpers.Hearts.HALF_SOUL,
    count = 1
}
