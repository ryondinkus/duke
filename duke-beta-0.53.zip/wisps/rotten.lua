return {
    heart = DukeHelpers.Hearts.ROTTEN,
    color = Color(0.8, 0.4, 0.3, 1, 0, 0, 0),
    tearFlags = TearFlags.TEAR_POISON
}
