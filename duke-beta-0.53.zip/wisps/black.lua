return {
    heart = DukeHelpers.Hearts.BLACK,
    color = Color(0.1, 0.1, 0.1, 1, 0, 0, 0),
    tearFlags = TearFlags.TEAR_FEAR
}
