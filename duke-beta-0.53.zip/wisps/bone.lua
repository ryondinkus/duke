return {
    heart = DukeHelpers.Hearts.BONE,
    color = Color(0.8, 0.8, 0.8, 1, 0, 0, 0),
    tearFlags = TearFlags.TEAR_CONFUSION
}
