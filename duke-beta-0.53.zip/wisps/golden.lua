return {
    heart = DukeHelpers.Hearts.GOLDEN,
    color = Color(0.8, 0.7, 0.2, 1, 0, 0, 0),
    tearFlags = TearFlags.TEAR_MIDAS
}
