return {
    heart = DukeHelpers.Hearts.BROKEN,
    count = 2,
    poofColor = Color(0.62, 0, 0, 1, 0, 0, 0),
    sticksInSlot = true
}
