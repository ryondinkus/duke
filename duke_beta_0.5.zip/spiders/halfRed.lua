return {
    use = include("spiders/red"),
    heart = DukeHelpers.Hearts.HALF_RED,
    count = 1
}
