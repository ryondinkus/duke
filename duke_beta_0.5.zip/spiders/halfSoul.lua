return {
    use = include("spiders/soul"),
    heart = DukeHelpers.Hearts.HALF_SOUL,
    count = 1
}
