DukeHelpers.Items = {
    dukesGullet = include("items/dukesGullet"),
    othersGullet = include("items/othersGullet"),
    thePrinces = include("items/thePrinces"),
    lilDuke = include("items/lilDuke"),
    dukeFlute = include("items/dukeFlute"),
    superInfestation = include("items/superInfestation"),
    fiendishSwarm = include("items/fiendishSwarm"),
    queenFly = include("items/queenFly"),
    shartyMcFly = include("items/shartyMcFly"),
    ultraHeartFly = include("items/ultraHeartFly"),
    rottenGullet = include("items/rottenGullet"),
    othersRottenGullet = include("items/othersRottenGullet"),
    dukeOfEyes = include("items/dukeOfEyes"),
	lilHusk = include("items/lilHusk"),
    theInvader = include("items/theInvader")
}
