return {
    use = include("flies/red"),
    heart = DukeHelpers.Hearts.PATCHED,
    count = 2
}
