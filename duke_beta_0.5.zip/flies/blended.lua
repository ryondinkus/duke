local uses = {
    {
        key = DukeHelpers.Hearts.RED.key,
        count = 1
    },
    {
        key = DukeHelpers.Hearts.SOUL.key,
        count = 1
    }
}

return {
    uses = uses,
    heart = DukeHelpers.Hearts.BLENDED,
    count = 1
}
