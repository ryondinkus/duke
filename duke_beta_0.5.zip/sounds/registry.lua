DukeHelpers.Sounds = {
	dukeFlute = Isaac.GetSoundIdByName("Duke Flute")
}
