return {
    use = include("flies/red"),
    heart = DukeHelpers.Hearts.DOUBLE_PATCHED,
    count = 4
}
