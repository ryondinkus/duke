DukeHelpers.EntityVariants = {
    lilDuke = include("entityVariants/lilDuke"),
    friendlyDuke = include("entityVariants/friendlyDuke"),
    shartyMcFly = include("entityVariants/shartyMcFly"),
    lovePoop = include("entityVariants/lovePoop"),
	lilHusk = include("entityVariants/lilHusk"),
    theInvader = include("entityVariants/theInvader")
}
