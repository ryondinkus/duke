return {
    use = include("spiders/red"),
    heart = DukeHelpers.Hearts.DOUBLE_PATCHED,
    count = 4
}
