DukeHelpers.Trinkets = {
    dukesTooth = include("trinkets/dukesTooth"),
    infestedHeart = include("trinkets/infestedHeart"),
    pocketOfFlies = include("trinkets/pocketOfFlies"),
    mosquito = include("trinkets/mosquito")
}
