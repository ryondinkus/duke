return {
    use = include("flies/red"),
    heart = DukeHelpers.Hearts.HALF_RED,
    count = 1
}
