local key = "FIENDISH"
local subType = 102

return {
    key = key,
    spritesheet = "fiendish_heart_fly.png",
    subType = subType,
    poofColor = Color(0.62, 0.62, 0.62, 1, 0.68, 0.22, 0.90),
    sacAltarQuality = 6,
    heartFlyDamageMultiplier = 1.3
}
