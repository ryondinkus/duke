return {
    use = include("flies/red"),
    heart = DukeHelpers.Hearts.DOUBLE_RED,
    count = 4
}
