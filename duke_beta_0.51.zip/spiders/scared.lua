return {
    use = include("spiders/red"),
    heart = DukeHelpers.Hearts.SCARED,
    count = 2
}
