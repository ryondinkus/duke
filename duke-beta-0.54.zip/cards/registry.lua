DukeHelpers.Cards = {
    tapewormCard = include("cards/tapewormCard"),
    redTapewormCard = include("cards/redTapewormCard"),
    soulOfDuke = include("cards/soulOfDuke")
}
