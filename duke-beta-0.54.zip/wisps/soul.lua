return {
    heart = DukeHelpers.Hearts.SOUL,
    color = Color(0.3, 0.5, 0.7, 1, 0, 0, 0),
    tearFlags = 0
}
