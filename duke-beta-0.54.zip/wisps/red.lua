return {
    heart = DukeHelpers.Hearts.RED,
    color = Color(0.8, 0.2, 0.3, 1, 0, 0, 0),
    tearFlags = 0
}
