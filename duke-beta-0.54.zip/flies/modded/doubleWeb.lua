return {
	use = include("flies/modded/web"),
	heart = DukeHelpers.Hearts.DOUBLE_WEB,
	count = 2
}
